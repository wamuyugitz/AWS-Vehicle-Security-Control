import os
import boto3
import logging
import time

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def upload_to_s3(local_directory, bucket_name, queue_url):
    """Upload files from a local directory to an S3 bucket and send a message to SQS with the file name."""
    # Create S3 and SQS clients with the desired region
    s3 = boto3.client('s3', region_name='us-east-1')
    sqs = boto3.client('sqs', region_name='us-east-1')

    try:
        for root, dirs, files in os.walk(local_directory):
            for file in files:
                local_path = os.path.join(root, file)
                s3_path = os.path.relpath(local_path, local_directory)

                # Upload the file to S3
                s3.upload_file(local_path, bucket_name, s3_path)
                logging.info(f"Uploaded '{local_path}' to '{bucket_name}/{s3_path}'")

                # Send a message to SQS with the file name
                sqs.send_message(QueueUrl=queue_url, MessageBody=s3_path)
                logging.info(f"Sent a message to SQS with file name '{s3_path}'")

                # Wait for 30 seconds before uploading the next file
                time.sleep(30)

    except Exception as e:
        logging.error(f"An error occurred: {e}")

if __name__ == "__main__":
    # Replace with your S3 bucket name and SQS queue URL
    bucket_name = "wamuyusbucket-s2110904"
    queue_url = "https://sqs.us-east-1.amazonaws.com/381492254495/wamuyu-image-processing-queue"
    local_directory = "/home/ec2-user/Images"

    upload_to_s3(local_directory, bucket_name, queue_url)
