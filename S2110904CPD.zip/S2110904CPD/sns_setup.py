import boto3

def create_sns_topic(topic_name):
    """Create an SNS topic and return its ARN."""
    sns_client = boto3.client('sns')
    response = sns_client.create_topic(Name=topic_name)
    return response['TopicArn']

def subscribe_email_to_topic(topic_arn, email_address):
    """Subscribe an email address to the SNS topic."""
    sns_client = boto3.client('sns')
    subscription = sns_client.subscribe(
        TopicArn=topic_arn,
        Protocol='email',
        Endpoint=email_address
    )
    return subscription['SubscriptionArn']

def main():
    topic_name = 'BlacklistAlert'
    email_address = 'w.gitonga@alustudent.com' 
    topic_arn = create_sns_topic(topic_name)
    print(f"Created SNS Topic ARN: {topic_arn}")
    
    subscription_arn = subscribe_email_to_topic(topic_arn, email_address)
    print(f"Subscription ARN: {subscription_arn}")

if __name__ == "__main__":
    main()
