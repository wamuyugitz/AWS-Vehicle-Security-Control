import boto3
# Specify AWS region
region = 'us-east-1'

# Initialize EC2 client
ec2_client = boto3.client('ec2', region_name=region)

# Define parameters for instance creation
instance_params = {
    'ImageId': 'ami-051f8a213df8bc089',        # Specify the AMI ID of the instance
    'InstanceType': 't2.micro',       # Specify the instance type
    'KeyName': 'gitz',  # Specify the key pair name for SSH access
    'SecurityGroupIds': ['sg-008b8b9cedc2e702e'],  # Specify security group IDs
    'MinCount': 1,                     # Minimum number of instances to launch
    'MaxCount': 1
}

# Create the EC2 instance
response = ec2_client.run_instances(**instance_params)

# Extract instance ID from the response
instance_id = response['Instances'][0]['InstanceId']

# Print the instance ID
print("EC2 instance created with Instance ID:", instance_id)
