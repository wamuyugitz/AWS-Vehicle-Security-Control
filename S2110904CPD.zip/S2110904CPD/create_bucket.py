import boto3
from botocore.exceptions import ClientError

# Create a Boto3 session object
session = boto3.Session(region_name='us-east-1')

# Get the S3 client from the session
s3_client = session.client('s3')
sqs_client = session.client('sqs')

# Define the bucket and queue names
bucket_name = 'wamuyusbucket-s2110904'
queue_name = 'wamuyu-image-processing-queue'
queue_url = 'https://sqs.us-east-1.amazonaws.com/381492254495/wamuyu-image-processing-queue'
queue_arn = 'arn:aws:sqs:us-east-1:381492254495:wamuyu-image-processing-queue'

try:
    # Create the S3 bucket
    bucket = s3_client.create_bucket(Bucket=bucket_name)
    print(f"Bucket '{bucket_name}' created successfully!")

    # Get the URL of the SQS queue
    queue_url = sqs_client.get_queue_url(QueueName=queue_name)['QueueUrl']
    queue_arn = sqs_client.get_queue_attributes(QueueUrl=queue_url, AttributeNames=['QueueArn'])['Attributes']['QueueArn']

    # Set up the notification configuration
    notification_configuration = {
        'QueueConfigurations': [
            {
                'QueueArn': queue_arn,
                'Events': ['s3:ObjectCreated:*'],
                'Filter': {
                    'Key': {
                        'FilterRules': [
                            {'Name': 'suffix', 'Value': 'jpg'}
                        ]
                    }
                }
            }
        ]
    }

    # Configure the bucket to send notifications to the SQS queue
    s3_client.put_bucket_notification_configuration(
        Bucket=bucket_name,
        NotificationConfiguration=notification_configuration
    )
    print(f"Notification configuration set for bucket '{bucket_name}' to send messages to SQS queue '{queue_name}'.")

except ClientError as e:
    print(f"Error occurred: {e}")

