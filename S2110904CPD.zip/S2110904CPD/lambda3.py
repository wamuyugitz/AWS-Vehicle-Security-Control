import boto3
import re
import json
import time

rekognition_client = boto3.client('rekognition')
dynamodb_client = boto3.client('dynamodb')
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    
   
    for sqs in event['Records']:
        try:
            body = json.loads(sqs['body'])
        except:
            file_name = sqs['body']
            image_s3_bucket = 'wamuyusbucket-s2110904'
            
            labels, detected_text = detect_labels_and_text(image_s3_bucket, file_name)
            store_results_in_dynamodb(file_name, labels, detected_text)
            return

        for record in body['Records']:
            try:
                file_name = record['s3']['object']['key']
                image_s3_bucket = record['s3']['bucket']['name']
                image_s3_key = file_name
                
                labels, detected_text = detect_labels_and_text(image_s3_bucket, image_s3_key)
                
                print("Detected labels:", labels)
                print("Detected text:", detected_text)
                
                #time.sleep(1)
                store_results_in_dynamodb(file_name, labels, detected_text)
                
            except Exception as e:
                raise e

def detect_labels_and_text(image_s3_bucket, image_s3_key):
    try:
        
        response_labels = rekognition_client.detect_labels(
            Image={
                'S3Object': {
                    'Bucket': image_s3_bucket,
                    'Name': image_s3_key
                }
            }
        )
        
        labels = [{'Name': label['Name'], 'Confidence': label['Confidence']} for label in response_labels.get('Labels', [])]
        
        #time.sleep(1)
        response_text = rekognition_client.detect_text(
            Image={
                'S3Object': {
                    'Bucket': image_s3_bucket,
                    'Name': image_s3_key
                }
            }
        )
        
        detected_text = [text['DetectedText'] for text in response_text.get('TextDetections', [])]
        
        print("The labels are:", labels)
        print("Detected text includes:", ", ".join(detected_text))
        
        return labels, detected_text
    except Exception as e:
        print(f"An error occurred while detecting labels and text: {e}")
        return [], []

def store_results_in_dynamodb(file_name, labels, detected_text):
    
    print("filename: ", file_name)
    try:
        dictionary = {}
        for label in labels:
            dictionary[label['Name']] = {'N': str(label['Confidence'])}
        print("The dictionary is:", dictionary)

        detected_text_str = ' '.join(detected_text) if detected_text else None
        
        extracted_text = None
        match = re.search(r'\b\d{4,}(\s\w{2}\s\d{2})?\b', detected_text_str)
        if match:
            extracted_text = match.group(0)
        
        print("Plate: ", extracted_text)
        # Check if the plate number exists in the vehicle table
        extracted_text = extracted_text.strip()
        
        vehicle_info = dynamodb_client.get_item(TableName='VehicleTable-s2110904', Key={'VehicleRegistration': {'S': extracted_text}})
        
        # If vehicle not found or blacklisted, send email notification
       
        print("blacklisted: ", vehicle_info['Item']['status']['S'])
        
        if vehicle_info['Item']['status']['S']=='blacklisted':
            send_email_notification(sns_client, extracted_text)
        
        print(f"Stored label results for {file_name} in DynamoDB.")
        
        dynamodb_client.put_item(
            TableName='VehicleEntryTable-s2110904',
            Item={
                'ImageName': {'S': file_name},
                'Labels': {'M': dictionary},
                'NumberPlate': {'S': extracted_text} if extracted_text else {'NULL': True}
            },
        )
    except Exception as e:
        raise e

# Function to send email notification
def send_email_notification(sns_client, extracted_text):
    try:
        subject = "Blacklisted Vehicle Detected"
        message = f"The plate number {extracted_text} has been detected as blacklisted."
        
        sns_client.publish(
            TopicArn='arn:aws:sns:us-east-1:381492254495:BlacklistAlert',
            Subject=subject,
            Message=message
        )
        print(f"Sending email notification for blacklisted vehicle detected: File Name - {extracted_text}, Plate Number - {extracted_text}")
    except Exception as e:
        print(f"Error sending email notification: {e}")